const pool = require('./../utils/bd');

const create = async(obj) => {
    const query = "INSERT INTO ?? SET ?";
    const params = [process.env.T_USUARIOS, obj];
    return await pool.query(query, params);
}
const verify = async(uid) => {
    const query = "UPDATE ?? SET habilitado = 1 WHERE confirmacionMail = ?"
    const params = [process.env.T_USUARIOS, uid];
    return await pool.query(query, params);
}
const auth = async(username, pass) => {
    const query = "SELECT id_usuario, admin FROM ?? WHERE username = ? AND pass = ? AND habilitado = 1 AND eliminado = 0";
    const params = [process.env.T_USUARIOS, username, pass];
    return await pool.query(query, params);
}
const single = async(id_usuario) => {
    const query = "SELECT * FROM ?? WHERE id_usuario = ?";
    const params = [process.env.T_USUARIOS, id_usuario];
    console.log(params);
    return await pool.query(query, params);
}
const update = async(id_usuario, obj) => {
    const query = "UPDATE ?? SET ? WHERE id_usuario = ?";
    const params = [process.env.T_USUARIOS, obj, id_usuario];
    console.log(params);
    return await pool.query(query, params);
}
const all = async() => {
    const query = "SELECT * FROM ?? WHERE eliminado = 0";
    const params = [process.env.T_USUARIOS];
    return await pool.query(query, params);
}
const deleteUsuario = async(id_usuario) => {
    const query = "UPDATE ?? SET eliminado = 1 WHERE id_usuario = ?";
    const params = [process.env.T_USUARIOS, id_usuario];
    return await pool.query(query, params);
}
module.exports = {create, verify, auth, single, update, all, deleteUsuario}