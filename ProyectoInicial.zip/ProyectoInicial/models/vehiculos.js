const pool = require('./../utils/bd');

const getAll = async() => {
    const query = "SELECT v.id_autos, v.marca, v.modelo, v.anio, v.precio, v.stock, c.nombre AS nombreCategoria FROM ?? AS v JOIN ?? AS c ON v.id_categorias = c.id WHERE v.eliminado = 0";
    // ?? == nombre de tabla ? == cualquier otra variable
    const params = [process.env.T_VEHICULOS, process.env.T_CATEGORIAS];
    // T_VEHICULOS = "VEHICULOS", T_CATEGORIAS = "categorias", T_USUARIOS = "usuarios"
    const rows = await pool.query(query, params);
    return rows;
}
const getSingle = async(id_autos) => {
    const query = "SELECT v.id_autos, v.marca, v.modelo, v.anio, v.precio, v.stock, v.id_categorias, c.nombre AS nombreCategoria FROM ?? AS v JOIN ?? AS c ON v.id_categorias = c.id WHERE v.id_autos = ? AND v.eliminado = 0";
    const params = [process.env.T_VEHICULOS, process.env.T_CATEGORIAS, id_autos];
    const rows = await pool.query(query, params);
    return rows;
}
const create = async(obj) => {
    const query = "INSERT INTO ?? SET ?";
    const params = [process.env.T_VEHICULOS, obj];
    return await pool.query(query, params);
}
const updateVehiculos = async(id_autos, obj) => {
    const query = "UPDATE ?? SET ? WHERE id_autos = ?";
    const params = [process.env.T_VEHICULOS, obj, id_autos];
    return await pool.query(query, params);
}
const del = async(id_autos) => {
    const query = "UPDATE ?? SET eliminado = 1 WHERE id_autos = ?";
    const params = [process.env.T_VEHICULOS, id_autos];
    return await pool.query(query, params);
}
const getNombre = async(marca) => {
    const query = "SELECT v.id_autos, v.marca, v.modelo, v.anio, v.precio, v.stock, v.id_categorias, c.nombre AS nombreCategoria FROM ?? AS v JOIN ?? AS c ON v.id_categorias = c.id WHERE v.marca LIKE ? AND v.eliminado = 0";
    const params = [process.env.T_VEHICULOS, process.env.T_CATEGORIAS, marca];
    const rows = await pool.query(query, params);
    return rows;
}



module.exports = {getAll, getSingle, create, updateVehiculos, del, getNombre}