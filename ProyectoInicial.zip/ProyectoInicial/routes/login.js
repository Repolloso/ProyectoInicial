const express = require('express'); //codigo de la muerte (se repite en js de routes)
const router = express.Router(); //codigo de la muerte (se repite en js de routes)
const {auth} = require('./../models/usuarios')//aca pide a la funcion auth de models que consulte a la base de datos la veracidad de los datos ingresados por el usuario
const sha1 = require('sha1'); // el sha1 es el modulo que esconde la constrasenia del usuario en el bdd.
const {validateLogin} = require('./../middlewares/usuarios');

const showLogin = (req, res) => res.render('login', {message : ''}); //aca renderiza la vista "login" en una funcion, sin dar un mensaje

const login = async (req, res) => { 
    let {username, pass} = req.body;//se pone req.body porque el username y la pass vienen de lo que el usuario pone en forms
    pass = sha1(pass); //encripta la contrasenia del usuario
    const logeado = await auth(username, pass); //aca lo que hace es que se llama a auth de models para consultar a la bdd
    console.log(logeado);
    if (logeado.length === 0){
        res.render('login', {message: 'Usuario o contraseña incorrectos'})
    } 
    else {//preguntar lo que sucede en este apartado
        const [{id_usuario, admin}] = logeado;
        req.session.user = id_usuario;
        req.session.admin = admin;
        admin == 1 ? res.redirect('/admin') : res.redirect('/vehiculos');
    }
}

router.get('/', showLogin);//trae data del sv y la manda al html
router.post('/', validateLogin, login);//manda info al servidor (que se va a agregar) 
module.exports = router;//exporta la carpeta router a todo el vsc para que pueda ser usado en otros js.