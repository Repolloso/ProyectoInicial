const express = require('express');
const router = express.Router();
const models = require('./../../models/categorias')

const getAllCat = async (req, res) => {
    const categorias = await models.getAllCategorias();
    res.render('adminCategorias', {categorias})
}

const getSingleCat = async (req, res) => {
    const {id} = req.params;
    const categoria = await models.getSingleCategorias(id);
    res.render('categoria', {categoria})
}

const createCat = async (req, res) => {
    const {body: categoria} = req;
    const messageIdcat = await models.createCategorias(categoria)
    res.redirect('/admin/categorias');
}

const showCreateCat = async (req, res) => {
    res.render('createCategorias');
}

const updateCat = async (req, res) => {
    const {id} = req.params;
    const categoria = req.body;
    const insertId = await models.updateCategorias(id, categoria); 
    console.log(insertId);
    res.redirect('/admin/categorias')
}

const showUpdateCat = async (req, res) => {
    const {id} = req.params;
    const [categoria] = await models.getSingleCategorias(id);
    res.render('updateCategorias', {id, categoria})
}

const deleteCat = async (req, res) => {
    const {id} = req.params;
    const {messageId} = await models.deleteCategorias(id);
    res.redirect('/admin/categorias');
}

router.get('/delete/:id', deleteCat)
router.get('/update/:id', showUpdateCat)//mostrar la pagina donde voy a mostrar la categoria, esto va en el front (se pone la ruta con update)
router.post('/update/:id', updateCat)
router.get('/single/:id', getSingleCat)
router.get('/', getAllCat)
router.post('/create', createCat)//el post es la accion con la bd cuando doy enter a un button
router.get('/create', showCreateCat)//los get son los que usan el front

module.exports = router;