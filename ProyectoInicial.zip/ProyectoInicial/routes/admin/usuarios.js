const express = require('express');
const router = express.Router();
const model = require('./../../models/usuarios');

const getAllUsuarios = async (req, res) => {
    const usuarios = await model.all();
    res.render('adminUsuarios', {usuarios})
}

const getSingleUsuarios = async (req, res) => {
    const {id_usuario} = req.params;
    const usuario = await model.single(id_usuario);
    res.render('usuario', {usuario})
}

const updateUsuarios = async (req, res) => {
    const {id_usuario} = req.params;
    const usuario = req.body;
    const {insertId} = await model.update(id_usuario, usuario); 
    console.log(JSON.stringify(insertId));
    res.redirect('/admin/usuarios')
}

const showUpdateUsuarios = async (req, res) => {
    const {id_usuario} = req.params;
    const [usuario] = await model.single(id_usuario);
    res.render('updateUsuarios', {usuario})
}

const deleteUsuarios = async (req, res) => {
    const {id_usuario} = req.params;
    const {messageId} = await model.deleteUsuario(id_usuario);
    res.redirect('/admin/usuarios');
}

router.get('/delete/:id_usuario', deleteUsuarios)
router.get('/update/:id_usuario', showUpdateUsuarios) //cuando linkee el form, el action (desde el front) tengo que poner /admin/usuarios/update/{id_usuario} NO PONER SHOWUPDATE PORQUE ESA ES LA FUNCION PARA EJECUTAR puedo hacer que se llame showupdate pero debo cambiarlo en /showupdateUsuarios/:id_usuario
router.post('/update/:id_usuario', updateUsuarios)
router.get('/single/:id_usuario', getSingleUsuarios)
router.get('/', getAllUsuarios)

module.exports = router;