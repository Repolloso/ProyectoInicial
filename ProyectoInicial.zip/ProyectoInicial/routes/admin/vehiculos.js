const express = require('express');
const router = express.Router();
const model = require('./../../models/vehiculos');
const modelCategorias = require('./../../models/categorias');

const get = async(req,res) => {
    const vehiculos = await model.getAll();
    res.render('adminVehiculos' , {vehiculos});
}
const showCreate = async (req, res) => {
    const categorias = await modelCategorias.getAllCategorias();
    console.log(categorias);
    res.render('createVehiculos', {categorias});
}
const create = async (req, res) => {
    const vehiculo = req.body;
    console.log(vehiculo);
    const {insertId} = await model.create(vehiculo);
    console.log(insertId);
    res.redirect('/admin/vehiculos');
}
const update = async (req, res) => {
    const {id_autos} = req.params;
    const {body: vehiculo} = req;
    const {insertId} = await model.updateVehiculos(id_autos, vehiculo);
    res.redirect('/admin/vehiculos');
}
const showUpdate = async (req, res) => {
    const {id_autos} = req.params;
    const [vehiculo] = await model.getSingle(id_autos);
    const categorias = await modelCategorias.getAllCategorias();
    console.log(JSON.stringify(vehiculo))
    res.render('updateVehiculo', {vehiculo, categorias, id_autos});
}
const del = async (req, res) => {
    const {id_autos} = req.params;
    const {insertId} = await model.del(id_autos);
    console.log(insertId);
    res.redirect('/admin/vehiculos');
}
router.get('/', get);
router.get('/create', showCreate);
router.post('/create', create);
router.get('/update/:id_autos', showUpdate);
router.post('/update/:id_autos', update);
router.get('/delete/:id_autos', del);
module.exports = router;