const express = require('express');
const router = express.Router();
const {getAll, getSingle, getNombre} = require('./../models/vehiculos');
const {verifyUser} = require('./../middlewares/auth')

const get = async(req, res) => {
    const vehiculos = await getAll();
    console.log(vehiculos);
    res.render('vehiculos', {vehiculos});
}
const single = async(req, res) => {
    const {id_autos} = req.params;
    const [vehiculo] = await getSingle(id_autos);
    res.render('vehiculo', {vehiculo});
}
const buscador = async(req, res) => {
    let {aBuscar} = req.body;
    aBuscar = '%' + aBuscar + '%';
    const vehiculos = await getNombre(aBuscar);
    console.log(vehiculos);
    res.render('vehiculos', {vehiculos});
}

router.get('/', get);
router.get('/single/:id_autos', single);
router.post('/', buscador);
module.exports = router;